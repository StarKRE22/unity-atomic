namespace Atomic.Elements
{
    //TODO: REACTIVE
    public interface IAtomicSet
    {
        
    }
}