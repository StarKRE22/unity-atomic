namespace Atomic.Elements
{
    public interface IAtomicTickable
    {
        void Tick(float deltaTime);
    }
}