using Atomic.Elements;
using Atomic.Objects;

namespace Atomic
{
    public sealed class AtomicTimerTicker : IEnable, IDisable, IUpdate, IFixedUpdate, ILateUpdate
    {
        private readonly AtomicTimer timer;
        private readonly TickMode tickMode;

        public AtomicTimerTicker(AtomicTimer timer, TickMode tickMode = TickMode.UPDATE)
        {
            this.timer = timer;
            this.tickMode = tickMode;
        }
        
        public void Enable(IObject obj)
        {
            this.timer.Start();
        }

        public void Disable(IObject obj)
        {
            this.timer.Stop();
        }

        public void OnUpdate(IObject obj, float deltaTime)
        {
            if (this.tickMode == TickMode.UPDATE)
            {
                this.timer.Tick(deltaTime);
            }
        }
        
        public void OnFixedUpdate(IObject obj, float deltaTime)
        {
            if (this.tickMode == TickMode.FIXED_UPDATE)
            {
                this.timer.Tick(deltaTime);
            }
        }

        public void OnLateUpdate(IObject obj, float deltaTime)
        {
            if (this.tickMode == TickMode.LATE_UPDATE)
            {
                this.timer.Tick(deltaTime);
            }
        }
    }
}