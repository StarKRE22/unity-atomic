namespace Atomic
{
    public enum TickMode
    {
        UPDATE = 0,
        FIXED_UPDATE = 1,
        LATE_UPDATE = 2,
    }
}