using UnityEngine;

namespace Atomic.Objects
{
    [AddComponentMenu("Atomic/Mono Composer")]
    [DisallowMultipleComponent]
    public class ObjectInstallerGroup : ObjectInstaller
    {
        [SerializeReference]
        private IAspect[] aspects;

        public override void Install(IObject obj)
        {
            if (this.aspects is {Length: > 0})
            {
                for (int i = 0, count = this.aspects.Length; i < count; i++)
                {
                    IAspect aspect = this.aspects[i];
                    if (aspect != null)
                    {
                        aspect.Compose(obj);
                    }
                }
            }
        }

        //TODO: ???
        // public void Discard(IAtomicObject obj)
        // {
        //     if (this.aspects is {Length: > 0})
        //     {
        //         for (int i = 0, count = this.aspects.Length; i < count; i++)
        //         {
        //             IAspect aspect = this.aspects[i];
        //             if (aspect != null)
        //             {
        //                 aspect.Discard(obj);
        //             }
        //         }
        //     }
        // }
    }
}