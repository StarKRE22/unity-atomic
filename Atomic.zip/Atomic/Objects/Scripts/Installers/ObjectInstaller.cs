using UnityEngine;

namespace Atomic.Objects
{
    public abstract class ObjectInstaller : MonoBehaviour
    {
        public abstract void Install(IObject obj);
    }
}