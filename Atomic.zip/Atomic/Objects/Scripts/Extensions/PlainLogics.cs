using System;
using UnityEngine;

namespace Atomic.Objects
{
    [Serializable]
    public sealed class AtomicAwake : IAwake
    {
        private Action<IObject> action;

        public AtomicAwake()
        {
        }

        public AtomicAwake(Action<IObject> action)
        {
            this.action = action;
        }

        public void Compose(Action<IObject> action)
        {
            this.action = action;
        }

        public void OnAwake(IObject obj)
        {
            this.action?.Invoke(obj);
        }
    }

    [Serializable]
    public sealed class AtomicEnable : IEnable
    {
        private Action<IObject> action;

        public AtomicEnable()
        {
        }

        public AtomicEnable(Action<IObject> action)
        {
            this.action = action;
        }

        public void Compose(Action<IObject> action)
        {
            this.action = action;
        }

        public void Enable(IObject obj)
        {
            this.action?.Invoke(obj);
        }
    }

    [Serializable]
    public sealed class AtomicDisable : IDisable
    {
        private Action<IObject> action;

        public AtomicDisable()
        {
        }

        public AtomicDisable(Action<IObject> action)
        {
            this.action = action;
        }

        public void Compose(Action<IObject> action)
        {
            this.action = action;
        }

        public void Disable(IObject obj)
        {
            this.action?.Invoke(obj);
        }
    }

    [Serializable]
    public sealed class AtomicUpdate : IUpdate
    {
        private Action<IObject, float> action;

        public AtomicUpdate()
        {
        }

        public AtomicUpdate(Action<IObject, float> action)
        {
            this.action = action;
        }

        public void Compose(Action<IObject, float> action)
        {
            this.action = action;
        }

        public void OnUpdate(IObject obj, float deltaTime)
        {
            this.action?.Invoke(obj, deltaTime);
        }
    }

    [Serializable]
    public sealed class AtomicFixedUpdate : IFixedUpdate
    {
        private Action<IObject, float> action;

        public AtomicFixedUpdate()
        {
        }

        public AtomicFixedUpdate(Action<IObject, float> action)
        {
            this.action = action;
        }

        public void Compose(Action<IObject, float> action)
        {
            this.action = action;
        }

        public void OnFixedUpdate(IObject obj, float deltaTime)
        {
            this.action?.Invoke(obj, deltaTime);
        }
    }

    [Serializable]
    public sealed class AtomicLateUpdate : ILateUpdate
    {
        private Action<IObject, float> action;

        public AtomicLateUpdate()
        {
        }

        public AtomicLateUpdate(Action<IObject, float> action)
        {
            this.action = action;
        }

        public void Compose(Action<IObject, float> action)
        {
            this.action = action;
        }

        public void OnLateUpdate(IObject obj, float deltaTime)
        {
            this.action?.Invoke(obj, deltaTime);
        }
    }

    [Serializable]
    public sealed class AtomicDrawGizmos : IDrawGizmos
    {
        private Action<IObject> action;

        public AtomicDrawGizmos()
        {
        }

        public AtomicDrawGizmos(Action<IObject> action)
        {
            this.action = action;
        }

        public void Compose(Action<IObject> action)
        {
            this.action = action;
        }

        public void OnGizmosDraw(IObject obj)
        {
            this.action?.Invoke(obj);
        }
    }

    [Serializable]
    public sealed class AtomicTriggerEnter : ITriggerEnter
    {
        private Action<IObject, Collider> action;

        public AtomicTriggerEnter()
        {
        }

        public AtomicTriggerEnter(Action<IObject, Collider> action)
        {
            this.action = action;
        }

        public void Compose(Action<IObject, Collider> action)
        {
            this.action = action;
        }

        public void TriggerEnter(IObject obj, Collider trigger)
        {
            this.action?.Invoke(obj, trigger);
        }
    }

    [Serializable]
    public sealed class AtomicTriggerExit : ITriggerExit
    {
        private Action<IObject, Collider> action;

        public AtomicTriggerExit()
        {
        }

        public AtomicTriggerExit(Action<IObject, Collider> action)
        {
            this.action = action;
        }

        public void Compose(Action<IObject, Collider> action)
        {
            this.action = action;
        }

        public void TriggerExit(IObject obj, Collider trigger)
        {
            this.action?.Invoke(obj, trigger);
        }
    }

    [Serializable]
    public sealed class AtomicCollisionEnter : ICollisionEnter
    {
        private Action<IObject, Collision> action;

        public AtomicCollisionEnter()
        {
        }

        public AtomicCollisionEnter(Action<IObject, Collision> action)
        {
            this.action = action;
        }

        public void Compose(Action<IObject, Collision> action)
        {
            this.action = action;
        }

        public void CollisionEnter(IObject obj, Collision collision)
        {
            this.action?.Invoke(obj, collision);
        }
    }

    [Serializable]
    public sealed class AtomicCollisionExit : ICollisionExit
    {
        private Action<IObject, Collision> action;

        public AtomicCollisionExit()
        {
        }

        public AtomicCollisionExit(Action<IObject, Collision> action)
        {
            this.action = action;
        }

        public void Compose(Action<IObject, Collision> action)
        {
            this.action = action;
        }

        public void CollisionExit(IObject obj, Collision collision)
        {
            this.action?.Invoke(obj, collision);
        }
    }

    [Serializable]
    public sealed class AtomicTriggerEnter2D : ITriggerEnter2D
    {
        private Action<IObject, Collider2D> action;

        public AtomicTriggerEnter2D()
        {
        }

        public AtomicTriggerEnter2D(Action<IObject, Collider2D> action)
        {
            this.action = action;
        }

        public void Compose(Action<IObject, Collider2D> action)
        {
            this.action = action;
        }

        public void TriggerEnter2D(IObject obj, Collider2D trigger)
        {
            this.action?.Invoke(obj, trigger);
        }
    }

    [Serializable]
    public sealed class AtomicTriggerExit2D : ITriggerExit2D
    {
        private Action<IObject, Collider2D> action;

        public AtomicTriggerExit2D()
        {
        }

        public AtomicTriggerExit2D(Action<IObject, Collider2D> action)
        {
            this.action = action;
        }

        public void Compose(Action<IObject, Collider2D> action)
        {
            this.action = action;
        }

        public void TriggerExit2D(IObject obj, Collider2D trigger)
        {
            this.action?.Invoke(obj, trigger);
        }
    }

    [Serializable]
    public sealed class AtomicCollisionEnter2D : ICollisionEnter2D
    {
        private Action<IObject, Collision2D> action;

        public AtomicCollisionEnter2D()
        {
        }

        public AtomicCollisionEnter2D(Action<IObject, Collision2D> action)
        {
            this.action = action;
        }

        public void Compose(Action<IObject, Collision2D> action)
        {
            this.action = action;
        }

        public void CollisionEnter2D(IObject obj, Collision2D collision)
        {
            this.action?.Invoke(obj, collision);
        }
    }

    [Serializable]
    public sealed class AtomicCollisionExit2D : ICollisionExit2D
    {
        private Action<IObject, Collision2D> action;

        public AtomicCollisionExit2D()
        {
        }

        public AtomicCollisionExit2D(Action<IObject, Collision2D> action)
        {
            this.action = action;
        }

        public void Compose(Action<IObject, Collision2D> action)
        {
            this.action = action;
        }

        public void CollisionExit2D(IObject obj, Collision2D collision)
        {
            this.action?.Invoke(obj, collision);
        }
    }
}