using System;
using UnityEngine;

namespace Atomic.Objects
{
    public static class LogicExtensions
    {
        public static ILogic WhenAwake(this IObject obj, Action<IObject> action)
        {
            var behaviour = new AtomicEnable(action);
            obj.AddLogic(behaviour);
            return behaviour;
        }
        
        public static ILogic WhenEnable(
            this IObject obj,
            Action<IObject> action
        )
        {
            var behaviour = new AtomicEnable(action);
            obj.AddLogic(behaviour);
            return behaviour;
        }
        
        public static ILogic WhenDisable(
            this IObject obj,
            Action<IObject> action
        )
        {
            var behaviour = new AtomicDisable(action);
            obj.AddLogic(behaviour);
            return behaviour;
        }
        
        public static ILogic WhenUpdate(
            this IObject obj,
            Action<IObject, float> action
        )
        {
            var behaviour = new AtomicUpdate(action);
            obj.AddLogic(behaviour);
            return behaviour;
        }

        public static ILogic WhenFixedUpdate(
            this IObject obj,
            Action<IObject, float> action
        )
        {
            var behaviour = new AtomicFixedUpdate(action);
            obj.AddLogic(behaviour);
            return behaviour;
        }

        public static ILogic WhenLateUpdate(
            this IObject obj,
            Action<IObject, float> action
        )
        {
            var behaviour = new AtomicLateUpdate(action);
            obj.AddLogic(behaviour);
            return behaviour;
        }

#if UNITY_EDITOR
        //Don't wrap UNITY_EDITOR
        public static ILogic WhenDrawGizmos(
            this IObject obj,
            Action<IObject, float> action
        )
        {
            var behaviour = new AtomicLateUpdate(action);
            obj.AddLogic(behaviour);
            return behaviour;
        }
#endif
        
        public static ILogic WhenTriggerEnter(
            this IObject obj,
            Action<IObject, Collider> action
        )
        {
            ILogic logic = new AtomicTriggerEnter(action);
            obj.AddLogic(logic);
            return logic;
        }
        
        public static ILogic WhenTriggerExit(
            this IObject obj,
            Action<IObject, Collider> action
        )
        {
            ILogic logic = new AtomicTriggerExit(action);
            obj.AddLogic(logic);
            return logic;
        }
        
        public static ILogic WhenCollisionEnter(
            this IObject obj,
            Action<IObject, Collision> action
        )
        {
            ILogic logic = new AtomicCollisionEnter(action);
            obj.AddLogic(logic);
            return logic;
        }
        
        public static ILogic WhenCollisionExit(
            this IObject obj,
            Action<IObject, Collision> action
        )
        {
            ILogic logic = new AtomicCollisionExit(action);
            obj.AddLogic(logic);
            return logic;
        }
        
        
        public static ILogic WhenTriggerEnter2D(
            this IObject obj,
            Action<IObject, Collider2D> action
        )
        {
            ILogic logic = new AtomicTriggerEnter2D(action);
            obj.AddLogic(logic);
            return logic;
        }
        
        public static ILogic WhenTriggerExit2D(
            this IObject obj,
            Action<IObject, Collider2D> action
        )
        {
            ILogic logic = new AtomicTriggerExit2D(action);
            obj.AddLogic(logic);
            return logic;
        }
        
        public static ILogic WhenCollisionEnter2D(
            this IObject obj,
            Action<IObject, Collision2D> action
        )
        {
            ILogic logic = new AtomicCollisionEnter2D(action);
            obj.AddLogic(logic);
            return logic;
        }
        
        public static ILogic WhenCollisionExit2D(
            this IObject obj,
            Action<IObject, Collision2D> action
        )
        {
            ILogic logic = new AtomicCollisionExit2D(action);
            obj.AddLogic(logic);
            return logic;
        }
    }
}