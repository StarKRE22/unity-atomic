using UnityEngine;

namespace Atomic.Objects
{
    public abstract class ScriptableLogic : ScriptableObject, ILogic
    {
    }
}