namespace Atomic.Objects
{
    // public interface IComposer
    // {
    // }
    //
    // public interface IDisposer
    // {
    // }

    public interface IAspect
    {
        void Compose(IObject obj);
        void Dispose(IObject obj);
    }
}