// using UnityEngine;
//
// namespace Atomic.Objects
// {
//     public abstract class ScriptableObjectComposer : ScriptableObject, IComposer
//     {
//         public abstract void Compose(IObject obj);
//     }
// }