using System;
using UnityEngine;

namespace GOAPModule
{
    [AttributeUsage(AttributeTargets.Field)]
    public sealed class WorldStateKeyAttribute : PropertyAttribute
    {
    }
}