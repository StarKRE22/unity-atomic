using System.Collections.Generic;

namespace Atomic.Objects
{
    public interface IAtomicBehaviour
    {
        ILogic[] AllLogic();

        int AllLogicNonAlloc(ILogic[] results);

        IList<ILogic> AllLogicUnsafe();
    }
}