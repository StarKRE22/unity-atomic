namespace Atomic.Objects
{
    public interface IMutalbleAtomicBehaviour : IAtomicBehaviour
    {
        void AddLogic(ILogic target);

        void RemoveLogic(ILogic target);
    }
}