namespace Atomic.Objects
{
    public interface IAtomicObject : IAtomicBehaviour, IAtomicEntity
    {
    }
}