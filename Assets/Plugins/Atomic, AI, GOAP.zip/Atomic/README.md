**Requirements:**
- Unity 2021+
- C# 8.0+
- Odin Inspector
