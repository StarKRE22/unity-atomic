using UnityEngine;

namespace AIModule
{
    //Marker Only
    public abstract class AILogic : ScriptableObject, IAILogic
    {
    }
}