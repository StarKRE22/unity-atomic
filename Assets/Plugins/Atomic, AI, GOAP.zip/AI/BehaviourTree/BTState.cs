namespace AIModule
{
    public enum BTState
    {
        RUNNING = 0,
        SUCCESS = 1,
        FAILURE = 2
    }
}