using System;
using UnityEngine;

namespace AIModule
{
    [Serializable]
    public sealed class BlackboardGameObject : BlackboardValue<GameObject>
    {
        public override void Apply(IBlackboard blackboard)
        {
            
        }
    }
}