namespace AIModule
{
    public interface IBlackboardValue
    {
        void Apply(IBlackboard blackboard);
    }
}