namespace AIModule
{
    public interface IAIState : IAIStartable, IAIStoppable, IAIUpdatable
    {
    }
}