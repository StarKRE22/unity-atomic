// namespace AI.GOAP
// {
//     public enum PlannerMode
//     {
//         Greedy = 0,
//         AStar = 1,
//         Dijkstra = 2,
//     }
// }