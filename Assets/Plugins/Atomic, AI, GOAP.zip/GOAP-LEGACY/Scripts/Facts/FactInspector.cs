// using UnityEngine;
//
// namespace AI.GOAP
// {
//     
//     public abstract class FactInspector : ScriptableObject
//     {
//         public abstract void PopulateFacts(FactState state);
//     }
// }