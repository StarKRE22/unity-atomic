// using UnityEngine;
//
// namespace AI.GOAP
// {
//     public sealed class FactKeyAttribute : PropertyAttribute
//     {
//     }
// }